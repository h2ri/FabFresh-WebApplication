'use strict';


routerApp
 .controller('address_listCTRL', function($window,$cookies, $rootScope,$scope, $http, $state,Pagination) {
   $scope.user = [];
   var URL = 'http://fabfresh-dev.elasticbeanstalk.com'
   $http({
     method  : 'GET',
     url     : URL+'/users/address/',
     headers : {'Authorization': 'Bearer '+$cookies.get('key')} 
    })
     .success(function(data) {
       if (data.errors) {
         alert("Some error occured");
       }
       else {
         $scope.data=data;
         $scope.l = data.length;
         console.log($scope.l);
         $scope.currentPage = 0;
         $scope.pagination = Pagination.getNew(2);
       }
     });

   $scope.check_couponvalidity = function() {
     //alert($scope.coupon);
     $scope.user = {
       "couponTag": $scope.coupon
     };
   $http({
     method  : 'POST',
     url     : URL+'/couponsvalididty/',
     data : $scope.user,
     headers : {'Authorization': 'Bearer '+$cookies.get('key'), 'Content-Type': 'application/json'} 
    })
     .success(function(data) {
       if (data.errors) {
         alert("Some error occured");
       } 
       else {
         //alert(data.status);
         if(data.status=="Invalid Coupon") {
           $scope.isvalid=data.status;
         }
         else{
          $scope.isvalid="Coupon Valid";
         }
       }
     });
   };
 
 

  $scope.placeorderForm = function() {
     //alert($scope.coupon);

     //console.log($rootScope.userid);
     //alert($scope.sp_request);
     //alert("user_id: "+$rootScope.userid+"address_id: "+$scope.id+"service_type: "+$scope.stype);
   $http({
     method  : 'GET',
     url     : URL+'/v1/placeorder/address/'+$scope.id+'/order/'+"0"+'/',
     params  :{type: $scope.stype},
     headers : {'Authorization': 'Bearer '+$cookies.get('key')} 
    })
    .success(function(data) {
        if (data.errors) {
          alert("Some error occured");
        } 
        else {
          console.log(data);
            alert("Successfully Placedorder");
            $state.go('orders');
        }
    });
  };



      var modal = document.getElementById('myModal');
      var modal1 = document.getElementById('myModal1');
      var modal2 = document.getElementById('myModal2');
      var modal3 = document.getElementById('myModal3');
      // Get the button that opens the modal
      var btn = document.getElementById("placebtn");
      var btn1 = document.getElementById("btn1");
      var btn2 = document.getElementById("btn2");
      var btn3 = document.getElementById("btn3");
      var btn4 = document.getElementById("btn4");
        

      // Get the <span> element that closes the modal
      // var span = document.getElementsByClassName("close")[0];

      // When the user clicks on the button, open the modal 
      btn.onclick = function() {
        //alert("sdfds");
          modal.style.display = "block";
      }

      btn1.onclick = function() {
        modal.style.display = "none";
        modal1.style.display = "block";
      }

      btn2.onclick = function() {
        modal1.style.display = "none";
        modal2.style.display = "block";
      }
      btn3.onclick = function() {
          modal2.style.display = "none";
          modal3.style.display = "block";
      }
      btn4.onclick = function() {
          modal3.style.display = "none";
      }



});


 