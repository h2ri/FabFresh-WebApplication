'use strict';

/**
 * @ngdoc overview
 * @name gauravApp
 * @description
 * # gauravApp
 *
 * Main module of the application.
angular
  .module('gauravApp', [
    'ngResource'
  ]);
*/
var routerApp = angular.module('routerApp', [
    'ui.router',
    'Login.services'
    ]);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        
        // HOME STATES AND NESTED VIEWS ========================================
        .state('login', {
            url: '/#',
            templateUrl: '../views/login.html',
            //controller: 'loginCTRL'
        })
        
       
         // nested list with custom controller
        .state('sign-up', {
            url: '/#',
            templateUrl: '../views/sign-up.html',
        })

        .state('forgot-password', {
            url: '/#',
            templateUrl: '../views/forgot-password.html',
        })
        .state('reset-password', {
            url: '/reset-password',
            templateUrl: '../views/reset-password.html',
        })
        // nested list with just some random string data
});