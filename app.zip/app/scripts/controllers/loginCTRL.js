'use strict';


angular.module('routerApp')
  .controller('loginCTRL', function($scope, loginAPIservice, $q) {
    $scope.ordersList = [];

    
    
    loginAPIservice.getOrders()
  .then(

    function(response){
       $scope.ordersList = response;
       alert(response.data);
    },
    function(httpError){
      throw httpError.status;   
    }
  );
  
});