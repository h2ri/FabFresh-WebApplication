'use strict';

/**
 * @ngdoc function
 * @name gauravApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the gauravApp
 */
angular.module('gauravApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
